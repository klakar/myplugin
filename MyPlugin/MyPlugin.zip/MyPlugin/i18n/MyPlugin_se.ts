<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="2.0">
<context>
    <name>@default</name>
    <message>
        <location filename="test_translations.py" line="48"/>
        <source>Good morning</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MyPlugin</name>
    <message>
        <location filename="my_plugin.py" line="214"/>
        <source>&amp;MyPlugin</source>
        <translation type="unfinished">&amp;MittPlugin</translation>
    </message>
    <message>
        <location filename="my_plugin.py" line="203"/>
        <source>My Plugin</source>
        <translation type="unfinished">Mitt Plugin</translation>
    </message>
</context>
<context>
    <name>MyPluginDialogBase</name>
    <message>
        <location filename="my_plugin_dialog_base.ui" line="14"/>
        <source>MyPlugin</source>
        <translation type="unfinished">MittPlugin</translation>
    </message>
    <message>
        <location filename="my_plugin_dialog_base.ui" line="26"/>
        <source>Create comma separeted list</source>
        <translation type="unfinished">Skapa kommaseparerad lista</translation>
    </message>
</context>
</TS>
